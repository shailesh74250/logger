// src/common/filters/all-exceptions.filter.ts

import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { LoggerService } from '../logger/logger.service';

@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  // private readonly logger = new Logger(AllExceptionsFilter.name);
  constructor(private readonly logger: LoggerService) {}
  // private readonly loggerService: LoggerService;

  catch(exception: unknown, host: ArgumentsHost): void {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();

    const timestamp = new Date().toISOString();
    const method = request.method;
    const path = request.url;
    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let message = 'Internal server error';
    let errorResponse: any = {};

    if (exception instanceof HttpException) {
      status = exception.getStatus();
      const res = exception.getResponse();
      if (typeof res === 'string') {
        message = res;
      } else if (typeof res === 'object') {
        const resObj = res as Record<string, any>;
        message = resObj.message || message;
        errorResponse = resObj;
      }
    } else if (exception instanceof Error) {
      message = exception.message;
    }

    const stack = exception instanceof Error ? exception.stack : null;
    const location = stack ? this.getErrorLocation(stack) : 'unknown';
    console.log('🚀 Exception Filter triggered!', status);
    // ✨ Smart Log Level based on Status
    if (status >= 500) {
      console.log('🚀 Exception Filter triggered!', message);
      this.logger.error(message, location, path)
    } else if (status >= 400) {
      this.logger.warn(`[${method}] ${path} -> ${message} (${location})`);
    } else {
      this.logger.log(`[${method}] ${path} -> ${message}`, location);
    }

    response.status(status).json({
      statusCode: status,
      timestamp,
      path,
      method,
      message,
      ...(errorResponse && typeof errorResponse === 'object'
        ? errorResponse
        : {}),
    });
  }

  private getErrorLocation(stack: string): string {
    const lines = stack.split('\n');
    if (lines.length >= 2) {
      const locationLine = lines[1];
      const match = locationLine.match(/\(([^)]+)\)/);
      return match ? match[1] : locationLine.trim();
    }
    return 'unknown';
  }
}
