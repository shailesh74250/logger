import { RabbitMQTransport } from 'src/shared/rabbitmq/services/rabbitmq.transport';
import { RabbitMQService } from '../../rabbitmq/services/rabbitmq.service';
import * as winston from 'winston';
import { LOGGER_LEVELS } from '../constants/logger.constants';

export class QueueTransport {
  private logger: winston.Logger;

  constructor(private readonly rabbitMQService: RabbitMQService) {
    this.logger = winston.createLogger({
      level: LOGGER_LEVELS.DEBUG, // Default log level
      format: winston.format.combine(
        winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        winston.format.json(),
      ),
      transports: [
       // new winston.transports.Console(),
        new RabbitMQTransport(this.rabbitMQService, {
          level: LOGGER_LEVELS.DEBUG,
          queue: 'cms-queue',
        }),
      ],
    });
  }

  log(level: string, message: string, context?: string): void {
    this.logger.log(level, message, { context });
  }

  error(message: string, trace: string, context?: string): void {
    this.logger.error(message, { trace, context });
  }
}