import * as TransportStream from 'winston-transport';
import { RabbitMQService } from './rabbitmq.service';

export class RabbitMQTransport extends TransportStream {
  private readonly queueName: string;

  constructor(
    private readonly rabbitMQService: RabbitMQService,
    options: { level: string; queue: string },
  ) {
    super({ level: options.level });
    this.queueName = options.queue;
  }

  async log(info: any, callback: () => void): Promise<void> {
    setImmediate(() => this.emit('logged', info));

    try {
      // Wait for RabbitMQService to be ready
      await this.rabbitMQService.ready();
      const channel = await this.rabbitMQService.getChannel();
      const message = JSON.stringify({
        level: info.level,
        module: info.context.split('/')[1],
        context: info.context,
        trace: info.trace,
        message: info.message,
        timestamp: new Date().toISOString(),
        ...info.meta,
      });

      const isSent = channel.sendToQueue(this.queueName, Buffer.from(message), {
        persistent: true,
      });
      
      if (isSent) {
        console.log(`✅ Message successfully pushed to queue "${this.queueName}":`, message);
      } else {
        console.warn(`⚠️ Message could not be pushed to queue "${this.queueName}":`, message);
      }
    } catch (error) {
      console.error('Failed to send log to RabbitMQ:', error);
    }

    callback();
  }
}