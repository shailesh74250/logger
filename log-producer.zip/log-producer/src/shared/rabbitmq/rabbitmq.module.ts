import { Global, Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { RabbitMQService } from './services/rabbitmq.service';

@Global()
@Module({
  imports: [ConfigModule],
  providers: [
    {
      provide: 'RABBITMQ_OPTIONS',
      useFactory: async (configService: ConfigService) => ({
        uri: configService.get<string>('RABBITMQ_URI'),
        queue: configService.get<string>('RABBITMQ_QUEUE', 'cms-queue'),
      }),
      inject: [ConfigService],
    },
    {
      provide: RabbitMQService,
      useFactory: (options: { uri: string; queue: string }) =>
        new RabbitMQService(options),
      inject: ['RABBITMQ_OPTIONS'],
    },
  ],
  exports: [RabbitMQService],
})
export class RabbitMQModule {}