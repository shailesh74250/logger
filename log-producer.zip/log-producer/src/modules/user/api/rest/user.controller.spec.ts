import { UserController } from "./user.controller"
import { UserService } from "../../domain/services/user.service";
import { Test } from "@nestjs/testing";
import UserDbEntity from "../../infrastructure/database/sql/entities/user.db.entity";

describe('User controller unit tests', () => {
  let userController: UserController;
  let userService: UserService;

  beforeEach(async() => {
    const moduleRef = await Test.createTestingModule({
      controllers: [UserController],
      providers: [
        {
          provide: UserService,
          useValue: {
            createUser: jest.fn(),
            getUserById: jest.fn(),
            updateUser: jest.fn(),
            deleteUser: jest.fn(),
            getAllUsers: jest.fn(),
          }
        }
      ]
    }).compile()

    userController = moduleRef.get<UserController>(UserController);
    userService = moduleRef.get<UserService>(UserService);
  })

  it('should return list of users', async () => {
    const dto = { id: '1', name: 'John Doe', email: 'john@example.com', password: '123456', createdAt: new Date(), updatedAt: new Date() };
    
    jest.spyOn(userService, 'getAllUsers').mockResolvedValue([dto])
    const result = await userController.getAllUsers()
    expect(result).toEqual([{...dto, createdAt: expect.any(Date), updatedAt: expect.any(Date)}])
  })

  it('should return single user according to passed id', async () => {
    const dto = {id: 'id', name: 'john doe', email: 'john@example.com', password: '123456', createdAt: new Date(), updatedAt: new Date() }
    
    jest.spyOn(userService, 'getUserById').mockResolvedValue(dto as any);
    expect(await userController.getUserById('1')).toEqual({...dto, createdAt: expect.any(Date), updatedAt: expect.any(Date)});
  })

  it('should create user and return created user', async () => {
    const dto = { name: 'John Doe', email: 'john@example.com', password: '123456' };
    
    jest.spyOn(userService, 'createUser').mockResolvedValue(dto as any);
    expect(await userController.createUser(dto)).toEqual(dto);
  })

  it('should update user and return updated user', async () => {
    const dto = {id: 'id', name: 'john doe', email: 'john@example.com', password: '123456', createdAt: new Date(), updatedAt: new Date() }
    
    jest.spyOn(userService, 'updateUser').mockResolvedValue(dto as any);
    expect(await userController.updateUser('1', dto)).toEqual({...dto, createdAt: expect.any(Date), updatedAt: expect.any(Date)});
  })

  it('should delete user and get status code 204 (no content)', async () => {
    const dto = {id: 'id', name: 'john doe', email: 'john@example.com', password: '123456', createdAt: new Date(), updatedAt: new Date() }
    
    jest.spyOn(userService, 'deleteUser').mockResolvedValue(dto as any);
    const result = await userController.deleteUser('1');
    expect(result.message).toEqual('User deleted successfully')
  })

  it.skip('should validate user before create', () => {

  })
  it.skip('should validate user before update', () => {

  })
})