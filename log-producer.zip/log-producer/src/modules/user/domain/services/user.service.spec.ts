import { Repository } from "sequelize-typescript";
import { getModelToken } from '@nestjs/sequelize';
import { UserService } from "./user.service";
import { User } from "../entities/user.entity";
import { Test } from "@nestjs/testing";

describe('UserService', () => {
  let service: UserService;
  let userModelMock: any;

  beforeEach(async () => {

    userModelMock = {
      getAllUsers: jest.fn().mockResolvedValue([{ id: '1', name: 'John Doe', email: 'john@example.com' }]),
      getUserById: jest.fn(),
      createUser: jest.fn(),
      updateUser: jest.fn(),
      deleteUser: jest.fn(),
    };

    const moduleRef = await Test.createTestingModule({
      providers: [
        UserService,
        {
          provide: getModelToken(User),
          useValue: userModelMock,
        },
      ],
    }).compile();

    service = moduleRef.get<UserService>(UserService);
    // userRepository = moduleRef.get<Repository<User>>(getRepositoryToken(UserEntity));
  });

  it('should return all users', async () => {
    const users = await service.getAllUsers();
    expect(users).toEqual([{ id: '1', name: 'John Doe', email: 'john@example.com' }]);
  });

  it.skip('should create a user', async () => {
    // const userDto = { name: 'John Doe', email: 'john@example.com', password: '123456' };
    // jest.spyOn(userRepository, 'save').mockResolvedValue(userDto as User);

    // const result = await userService.createUser(userDto);
    // expect(result).toEqual(userDto);
  });

  it.skip('should return a user by ID', async () => {
    // const user = { id: 1, name: 'John Doe', email: 'john@example.com' } as UserEntity;
    // jest.spyOn(userRepository, 'findOne').mockResolvedValue(user);

    // const result = await userService.getUserById(1);
    // expect(result).toEqual(user);
  });

  it.skip('should update a user', async () => {
    // const updatedUser = { name: 'Updated Name' };
    // jest.spyOn(userRepository, 'update').mockResolvedValue({ affected: 1 } as any);
    // jest.spyOn(userRepository, 'findOne').mockResolvedValue({ id: 1, ...updatedUser } as UserEntity);

    // const result = await userService.updateUser(1, updatedUser);
    // expect(result.name).toBe('Updated Name');
  });

  it.skip('should delete a user', async () => {
    // jest.spyOn(userRepository, 'delete').mockResolvedValue({ affected: 1 } as any);
    // const result = await userService.deleteUser(1);
    // expect(result).toBe(true);
  });

  it.skip('should return false when deleting a non-existing user', async () => {
    // jest.spyOn(userRepository, 'delete').mockResolvedValue({ affected: 0 } as any);
    // const result = await userService.deleteUser(100);
    // expect(result).toBe(false);
  });
});
