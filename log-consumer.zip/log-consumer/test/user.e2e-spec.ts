import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import * as request from 'supertest';
import { SequelizeModule } from '@nestjs/sequelize';
import { AppModule } from '../src/app.module';
import { User } from '../src/modules/user/domain/entities/user.entity';

describe('User E2E Tests', () => {
  let app: INestApplication;
  let server: any;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [
        AppModule,
        SequelizeModule.forRoot({
          dialect: 'postgres',
          host: 'localhost', // Change if running in Docker
          port: 5432,
          username: 'postgres',
          password: 'postgres',
          database: 'test_db',
          autoLoadModels: true,
          synchronize: true, // Enable in testing only
        }),
        User,
      ],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
    server = app.getHttpServer();
  });

  afterAll(async () => {
    await app.close();
  });

  describe('POST /users (Create User)', () => {
    it('should create a new user', async () => {
      const response = await request(server)
        .post('/users')
        .send({ name: 'John Doe', email: 'john@example.com', password: '123456' })
        .expect(201);

      expect(response.body).toHaveProperty('id');
      expect(response.body.email).toBe('john@example.com');
    });
  });

  describe('GET /users (Get All Users)', () => {
    it('should return a list of users', async () => {
      const response = await request(server).get('/users').expect(200);
      expect(Array.isArray(response.body)).toBe(true);
    });
  });

  describe('GET /users/:id (Get User by ID)', () => {
    let userId: string;

    beforeAll(async () => {
      const user = await request(server)
        .post('/users')
        .send({ name: 'Jane Doe', email: 'jane@example.com', password: '123456' });
      userId = user.body.id;
    });

    it('should return a user by ID', async () => {
      const response = await request(server).get(`/users/${userId}`).expect(200);
      expect(response.body.id).toBe(userId);
      expect(response.body.email).toBe('jane@example.com');
    });
  });

  describe('PUT /users/:id (Update User)', () => {
    let userId: string;

    beforeAll(async () => {
      const user = await request(server)
        .post('/users')
        .send({ name: 'Jane Doe', email: 'jane@example.com', password: '123456' });
      userId = user.body.id;
    });

    it('should update a user', async () => {
      const response = await request(server)
        .put(`/users/${userId}`)
        .send({ name: 'Jane Doe Updated' })
        .expect(200);

      expect(response.body.name).toBe('Jane Doe Updated');
    });
  });

  describe('DELETE /users/:id (Delete User)', () => {
    let userId: string;

    beforeAll(async () => {
      const user = await request(server)
        .post('/users')
        .send({ name: 'Mark Doe', email: 'mark@example.com', password: '123456' });
      userId = user.body.id;
    });

    it('should delete a user', async () => {
      await request(server).delete(`/users/${userId}`).expect(200);
      await request(server).get(`/users/${userId}`).expect(404);
    });
  });
});
