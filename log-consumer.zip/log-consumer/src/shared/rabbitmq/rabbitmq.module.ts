import { forwardRef, Global, Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { RabbitMQService } from './services/rabbitmq.service';
import { LoggerModule } from '../logger/logger.module';
import { LoggerService } from '../logger/logger.service';

@Global()
@Module({
  imports: [ConfigModule, forwardRef(() => LoggerModule)],
  providers: [
    {
      provide: 'RABBITMQ_OPTIONS',
      useFactory: async (configService: ConfigService) => ({
        uri: configService.get<string>('RABBITMQ_URI'),
        queue: configService.get<string>('RABBITMQ_QUEUE', 'cms-queue'),
      }),
      inject: [ConfigService],
    },
    {
      provide: RabbitMQService,
      useFactory: (
        options: { uri: string; queue: string },
        loggerService: LoggerService,
      ) => new RabbitMQService(options, loggerService),
      inject: ['RABBITMQ_OPTIONS', LoggerService], // Include LoggerService here
    },
  ],
  exports: [RabbitMQService],
})
export class RabbitMQModule {}