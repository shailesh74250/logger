import { forwardRef, Inject, Injectable, OnModuleInit } from '@nestjs/common';
import * as amqplib from 'amqplib';
import { Channel, Connection } from 'amqplib';
import { LoggerService } from 'src/shared/logger/logger.service';

@Injectable()
export class RabbitMQService implements OnModuleInit {
  private connection: Connection;
  private channel: Channel;
  private readonly readyPromise: Promise<void>;
  private isReady = false;

  constructor(
    private readonly options: { uri: string; queue: string },
    @Inject(forwardRef(() => LoggerService))
    private readonly logger: LoggerService,
  ) {
    this.readyPromise = this.initialize();
  }

  async onModuleInit(): Promise<void> {
    await this.readyPromise; // Ensure initialization is complete
  }

  private async initialize(): Promise<void> {
    try {
      this.connection = await amqplib.connect(this.options.uri);
      this.channel = await this.connection.createChannel();
      await this.channel.assertQueue(this.options.queue, { durable: true });
      this.isReady = true;
      console.log('✅ RabbitMQ connected and queue initialized');

      this.channel.consume(
        this.options.queue,
        (msg) => {
          if (msg !== null) {
            console.log('📥 Received message:', msg.content);
            let content = JSON.parse(msg.content.toString());
            // console.log('Logger instance:', new Date(content.timestamp).getTime());
            content.timestamp = new Date(content.timestamp).getTime();
            console.log({content});
            
              if(content.level === 'error') {
                this.logger.error(content.module, content.message, content.trace, content.context)
              } 
              else {
                this.logger.debug(`Message received: ${JSON.stringify(content)}`);
              }
           
            // Acknowledge message
            this.channel.ack(msg);
          }
        },
        { noAck: false },
      );
    } catch (error) {
      console.error('❌ Failed to initialize RabbitMQ:', error);
      throw error;
    }
  }

  async ready(): Promise<void> {
    await this.readyPromise; // Wait until RabbitMQ is ready
  }

  async getChannel(): Promise<Channel> {
    if (!this.isReady) {
      await this.ready(); // Ensure the service is ready before returning the channel
    }
    return this.channel;
  }

  getQueue(): string {
    return this.options.queue;
  }
}