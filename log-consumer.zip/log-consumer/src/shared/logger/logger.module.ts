import { Module, Global, forwardRef } from '@nestjs/common';
import { LoggerService } from './logger.service';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { LoggingInterceptor } from './logging.interceptor';
import { ConfigService } from '@nestjs/config'; //Vipul
import { RabbitMQModule } from '../rabbitmq/rabbitmq.module';

/**
 * Logger Module
 *
 * This module provides a configurable logger service that can be used across the application.
 * @decorator @Global
 * @decorator @Module
 */
@Global() // Makes the module available globally
@Module({
  imports: [forwardRef(() => RabbitMQModule)], // Use forwardRef here
  providers: [
    LoggerService,
    ConfigService,
    {
      provide: APP_INTERCEPTOR,
      useClass: LoggingInterceptor,
    },
  ],
  exports: [LoggerService], // Export LoggerService for use in other modules
})
export class LoggerModule {}
