import { forwardRef, Inject, Injectable } from '@nestjs/common';
import { ILoggerTransport } from './logger.interface';
import { ConsoleTransport } from './transports/console.transport';
import { FileTransport } from './transports/file.transport';
import { ConfigService } from '@nestjs/config';
import {
  LOGGER_CONFIG,
  LOGGER_LEVELS,
  LOGGER_TRANSPORTS,
} from './constants/logger.constants';
import { LogSanitizer } from './logger.sanitizer';
import { RabbitMQService } from '../rabbitmq/services/rabbitmq.service';

@Injectable()
export class LoggerService {
  private transports: ILoggerTransport[] = [];
  private allowedLevels: Set<string>;

  constructor(
    private readonly configService: ConfigService, // Correctly inject ConfigService
    @Inject(forwardRef(() => RabbitMQService)) // Use forwardRef only for RabbitMQService
    private readonly rabbitMQService: RabbitMQService,
  ) {
    this.initializeTransports();
    this.allowedLevels = new Set(
      (
        this.configService.get<string>('LOGGER_ALLOWED_LEVELS') ||
        LOGGER_CONFIG.DEFAULT_ALLOWED_LEVELS.join(',')
      )
        .split(',')
        .map((level) => level.trim()),
    );
  }

  private initializeTransports(): void {
    const transportsConfig = this.configService.get<{ TRANSPORTS: string }>(
      'LOGGER',
    );
    const transports = (transportsConfig &&
      transportsConfig.TRANSPORTS.split(',')) || [LOGGER_TRANSPORTS.CONSOLE];
    console.log(transports);
    transports.forEach((transport) => {
      switch (transport) {
        case LOGGER_TRANSPORTS.CONSOLE:
          this.transports.push(new ConsoleTransport());
          break;
        case LOGGER_TRANSPORTS.FILE:
          this.transports.push(new FileTransport());
          break;
        default:
          throw new Error(`Unsupported transport: ${transport}`);
      }
    });
  }

  log(level: string, message: string, context?: string): void {
    if (this.allowedLevels.has(level)) {
      const sanitizedMessage = LogSanitizer.sanitizeLogData(message);
      this.transports.forEach((transport) =>
        transport.log(level, sanitizedMessage, context),
      );
    }
  }

  error(module: string, message: string, trace: string, context?: string): void {
    if (this.allowedLevels.has(LOGGER_LEVELS.ERROR)) {
      const sanitizedMessage = LogSanitizer.sanitizeLogData(message);
      const sanitizedTrace = LogSanitizer.sanitizeErrorTrace(trace);
      const logEntry = {
        level: LOGGER_LEVELS.ERROR,
        module,
        message: sanitizedMessage,
        trace: sanitizedTrace,
        context,
        timestamp: Date.now(),
      };
      this.transports.forEach((transport) => {
        transport.error(logEntry.module,logEntry.message, logEntry.trace, logEntry.context);
      });
    }
  }

  warn(message: string, context?: string): void {
    this.log(LOGGER_LEVELS.WARN, message, context);
  }

  debug(message: string, context?: string): void {
    this.log(LOGGER_LEVELS.DEBUG, message, context);
  }

  info(message: string, context?: string): void {
    this.log(LOGGER_LEVELS.INFO, message, context);
  }
}