import { Controller } from '@nestjs/common';

@Controller('auth')
export class AuthController {
    // Define your authentication endpoints here
    // For example:
    // @Post('login')
    // async login(@Body() loginDto: LoginDto) {
    //   return this.authService.login(loginDto);
    // }    
}
